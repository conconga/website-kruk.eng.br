#!/usr/bin/python
#
# author:      Luciano Augusto Kruk
# website:     www.kruk.eng.br
#
# description: Generate pictures for the project.

import momat2dat          as lrf;
import numpy              as np;
import matplotlib.pyplot  as plt;
reload(lrf);

# content to look for:
lookfor = [ \
    'time',                  # [0] \
    'p.x',                   # [1] \
    'p.force'                # [2] \
]

# extract data and return a matrix:
data = lrf.fn_open_mat('main_res.mat', lookfor);

# figures:
fig = 0;
fig = fig + 1; plt.figure(fig); plt.clf();

plt.subplot(2,1,1);
plt.plot(data[:,0], data[:,2], hold=False);
plt.ylabel('force [N]')
plt.title('input');
plt.grid();

plt.subplot(2,1,2);
plt.plot(data[:,0], data[:,1], hold=False);
plt.ylabel('position [m]')
plt.title('output');
plt.grid();

#------------------#
plt.show(block=False);
#------------------#
